library(testthat)
library(familiar)

test_check("familiar")
